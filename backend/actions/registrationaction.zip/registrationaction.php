<?php
include 'db.php';

    if(isset($_POST["register"])){
        

        // GET THE DATA from user

        $uname=mysqli_real_escape_string($conn,$_POST['uname']);
        $fname=mysqli_real_escape_string($conn,$_POST['fname']);
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $phone=mysqli_real_escape_string($conn,$_POST['phone']);
        $country=mysqli_real_escape_string($conn,$_POST['country']);
        $pwd=mysqli_real_escape_string($conn,$_POST['pwd']);
        $btc=mysqli_real_escape_string($conn,$_POST['btc']);

         
        //this is the admin defined values
        $refidd=$_POST['refidd'];
        $amountpaid=0;
         $totalbal = 0;
        $totalwith  = 0;
        $lastdep=0;
        $earn = 0;
         $withdrawl  = 0;
         $refpay="not";
         $date=date("Y/m/d");
        
         //VALIDATE
 if (empty($uname)|| empty($fname)|| empty($email)|| empty($country)||empty($phone) || empty($pwd) || empty($btc)) {

                header ("Location:../register.php?signupempty");
                exit();
             
         }else{
           //VALIDATE EMAIL
            if(!filter_var($email,FILTER_VALIDATE_EMAIL)){

                header ("Location:../register.php?invalidemail");
                exit();

            }else{

                $sql = "SELECT * FROM users WHERE username='$uname';";
                $result = mysqli_query($conn,$sql);
                $result_check = mysqli_num_rows($result);

                if($result_check > 0){

                    header ("Location:../register.php?uidtaken");
                    exit();

                }else{

                    //harsh the password
                   // $hashpwd = password_hash($pwd, PASSWORD_DEFAULT);

                    // unique reference id
                     // $refcode = uniqid($usd,true);

$sql = "INSERT INTO users(username,fullname,email,pwd,country,phone,btcaddr,totalbal,totalwith,lastdeposit,earn,lastwith,registerdate,refpaid) VALUES ('$uname','$fname','$email','$pwd','$country','$phone','$btc','$totalbal','$totalwith','$lastdep','$earn','$withdrawl','$date','$refpay')";

//registeration email
$to = $email;
$subject = 'Welcome To  Safetrade-Capital';
$from = 'contact@safetrade-Capital.com';
 
// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 
// Compose a simple HTML email message
// <img src="http://www.yourserver.com/myimages/image1.jpg

$message = " <html><body style='width:100%;background: rgb(204, 225, 225);'>";
$message.=  "<div style='width:90%; height: auto; margin: auto;margin-top: 20px;box-shadow: 0px 0px 3px rgb(253, 150, 26);border-radius: 5px;'>";
$message.=  "<div style='width:100%;'>";
$message.=  "<h3 style='padding: 1px;font-family: Georgia; color:#083d6b'><span style='color:#083d6b'>SAFE</span>TRADE-CAPITAL</h3>";
// LOGO HERE
$message.=  "<img src='https://www.safetrade-capital.com/assets/img/bo.png' alt='logo' width='100' height='65'>";

// LOGO HERE
// $message.=  "<img src='https://www.algrocryptofund.com/imgs/log.jpg'>";
$message.=  "<h4 style='padding: 1px;'>Hello ". $uname. ",</h4> ";
$message.= " <br>";
$message.=  "<div style='width:100%;height: auto;box-shadow: 0px 0px 3px rgb(253, 150, 26);margin: auto;border-radius: 6px;'>";

$message.="<p style='color:blue;'><strong>WELCOME TO SAFETRADE-CAPITAL</strong></p>";


$message.="<p>Your registration was successful and we are glad you are part of us.</p>";
$message.="<p>To start earning, first make a deposit into your wallet.</p>";
$message.="<p>Choose an investment plan, invest and grow your financial dreams because the best is now.</p>";
$message.="<p>Your financial growth is our outmost interest, follow our terms and conditions and your financial freedom is guaranted.</p>";
$message.="<p>Your details and informations are secured with our high level encription database. Keep them private and don't share with third party</p>";

$message.="<p>For complaints or futher clearification, visit our website: www.safetrade-capital.com  and contact us .</p>";
$message.="<p> Start investing right away to earn outrightly!!.</p>";
$message.= "</div> ";
$message .=  "<p style='text-align:center;'>Safetrade-Capital © 2011-2021 All Rights Reserved</p> ";
$message.=  " </div>";
$message.=  "</div>";
$message.=  "</body></html>";


mail($to, $subject, $message, $headers);
 mysqli_query($conn,$sql);


                // WOEKING ON THE REFERENCE TABLE

             if($refidd == ''){

               }else{

                      $sql = "INSERT INTO reftable (username,email,fullname,phone,linkrefid,amountpaid) VALUES ('$uname','$email','$fname','$phone','$refidd','$amountpaid')";

                         mysqli_query($conn,$sql);



                         //sending referal mail notifications

                         if($refidd == ""){


                        }else{

                            $sql = "SELECT * FROM users WHERE username='$refidd' ";
                           $result = mysqli_query($conn,$sql);
                            $result_check = mysqli_num_rows($result);

                               if($result_check > 0){

                                      while($data = mysqli_fetch_assoc($result)){
                                        $fnr = $data['username'];
                                         $lnr= $data['fullname'];
                                            $emailr= $data['email'];


                                          // REFERAL EMAIL MSGE

 $to = $emailr;
 $subject = 'REFERAL NOTIFICATION';
 $from = 'contact@safetrade-capital.com';
 
 // To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
 $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
 
// Create email headers
 $headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 
// // Compose a simple HTML email message


 $message = " <html><body style='width:100%;background: rgb(247, 247, 247);'>";
 $message.=  "<div style='width:90%; height: auto; margin: auto;margin-top: 20px;box-shadow: 0px 0px 3px rgb(253, 150, 26);border-radius: 5px;'>";
 $message.=  "<div style='width:100%;'>";
 $message.=  "<h3 style='padding: 1px;font-family: Georgia; color:#083d6b'><span style='color:#083d6b'>SAFE</span>TRADE-CAPITAL</h3>";
 // LOGO HERE
 $message.=  "<img src='https://www.safetrade-capital.com/assets/img/bo.png' alt='logo' width='100' height='65'>";

$message.=  "<h4 style='padding: 1px;'>Hello ".$fnr." </h4> ";
 $message.= " <br>";
 $message.=  "<div style='width:100%;height: auto;box-shadow: 0px 0px 3px rgb(253, 150, 26);margin: auto;border-radius: 6px;'>";

 $message.="<p>".$fname." ".$ln." "." Just registered using your Referral Link</p>";

 $message.= "</div> ";
 $message .=  "<p style='text-align:center;'>Safetrade-capital © 2011-2021 All Rights Reserved</p> ";
 $message.=  " </div>";
 $message.=  "</div>";
 $message.=  "</body></html>";


 mail($to, $subject, $message, $headers);

  mysqli_query($conn,$sql);




         }
                            }

                         }




                     // END OF REFREAL LINL
                 }












             header ("Location:../login.php?signupsuc");
                 exit();


                }


            }



         }


        
    }else{
        header ("Location:../register.php?error");
        exit();
    }
